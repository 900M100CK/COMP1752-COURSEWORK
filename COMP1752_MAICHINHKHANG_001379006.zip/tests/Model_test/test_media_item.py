import pytest
from Model.media_item import MediaItem
from Model.song_item import SongItem


def test_create_media_item():
    """Test creating a new MediaItem with valid data"""
    media = MediaItem(
        media_id=1,
        title="Test Song",
        rating=4
    )
    assert media.media_id == 1
    assert media.title == "Test Song"
    assert media.rating == 4
    assert media.duration == 0
    assert media.genre == "Unknown"
    assert media.year == "Unknown"
    assert media.cover_url == ""


def test_media_item_info():
    """Test the info() method returns correct string format"""
    media = MediaItem(
        media_id=1,
        title="Test Song",
        rating=4
    )
    assert media.info() == "1 Test Song 4"


def test_media_item_to_dict():
    """Test converting MediaItem to dictionary"""
    media = MediaItem(
        media_id=1,
        title="Test Song",
        rating=4
    )
    result = media.to_dict()
    assert result == {
        "media_id": 1,
        "title": "Test Song",
        "rating": 4,
        "duration": 0,
        "genre": "Unknown",
        "year": "Unknown",
        "cover_url": ""
    }


def test_media_item_update():
    """Test updating MediaItem attributes"""
    media = MediaItem(
        media_id=1,
        title="Test Song",
        rating=4
    )

    # Update title
    media.title = "Updated Song"
    assert media.title == "Updated Song"

    # Update rating
    media.rating = 5
    assert media.rating == 5

    # Update other attributes
    media.duration = 180
    media.genre = "Pop"
    media.year = "2023"
    media.cover_url = "http://example.com/cover.jpg"

    assert media.duration == 180
    assert media.genre == "Pop"
    assert media.year == "2023"
    assert media.cover_url == "http://example.com/cover.jpg"


def test_invalid_rating():
    """Test creating MediaItem with invalid rating"""
    with pytest.raises(ValueError):
        MediaItem(
            media_id=1,
            title="Test Song",
            rating=6  # Rating must be between 1 and 5
        )

    with pytest.raises(ValueError):
        MediaItem(
            media_id=1,
            title="Test Song",
            rating=0  # Rating must be between 1 and 5
        )


def test_media_item_initialization():
    """Test khởi tạo MediaItem với dữ liệu hợp lệ"""
    media = MediaItem(
        media_id=1,
        title="Test Media",
        rating=4
    )
    assert media.media_id == 1
    assert media.title == "Test Media"
    assert media.rating == 4


def test_media_item_invalid_rating():
    """Test khởi tạo MediaItem với rating không hợp lệ"""
    with pytest.raises(ValueError):
        MediaItem(
            media_id=1,
            title="Test Media",
            rating=6  # Rating phải từ 1-5
        )


def test_song_item_duration():
    """Test xử lý duration của SongItem"""
    # Test với duration là 0
    song = SongItem(
        song_id=1,
        title="Test Song",
        artist="Test Artist",
        duration=0
    )
    assert song.duration == 0
    assert song.get_duration_formatted() == "00:00"
    
    # Test với duration là 65 giây (1 phút 5 giây)
    song.duration = 65
    assert song.duration == 65
    assert song.get_duration_formatted() == "01:05"
    
    # Test với duration là 125 giây (2 phút 5 giây)
    song.duration = 125
    assert song.duration == 125
    assert song.get_duration_formatted() == "02:05"
    
    # Test với duration là 3600 giây (1 giờ)
    song.duration = 3600
    assert song.duration == 3600
    assert song.get_duration_formatted() == "60:00"


def test_song_item_info_with_duration():
    """Test phương thức info() của SongItem có hiển thị duration"""
    song = SongItem(
        song_id=1,
        title="Test Song",
        artist="Test Artist",
        album="Test Album",
        duration=125
    )
    assert song.info() == "Test Song by Test Artist (Test Album) - 02:05"