class MediaItem:
    """
    Represents a media item in the jukebox application.
    Provides common attributes and methods for all media types.
    """
    def __init__(self, media_id, title, rating):
        """
        Initialize a media item with basic information

        Args:
            media_id (int): Unique identifier for the media item
            title (str): Title of the media item
            rating (int): User rating of the media item (1-5)
            
        Raises:
            ValueError: If rating is not between 1 and 5
        """
        if not isinstance(rating, int) or not 1 <= rating <= 5:
            raise ValueError("Rating must be an integer between 1 and 5")
            
        self.media_id = media_id
        self.title = title
        self.rating = rating

    def info(self):
        """
        Get a string representation of the media item
        
        Returns:
            str: String containing media_id, title, and rating
        """
        return f"{self.media_id} {self.title} {self.rating}"

    def to_dict(self):
        """
        Convert the media item to a dictionary
        
        Returns:
            dict: Dictionary containing all media item attributes
        """
        return {
            "media_id": self.media_id,
            "title": self.title,
            "rating": self.rating
        }

    def update(self, **kwargs):
        """
        Update media item attributes
        
        Args:
            **kwargs: Key-value pairs of attributes to update
        """
        for key, value in kwargs.items():
            if hasattr(self, key):
                if key == "rating" and (not isinstance(value, int) or not 1 <= value <= 5):
                    raise ValueError("Rating must be an integer between 1 and 5")
                setattr(self, key, value)
