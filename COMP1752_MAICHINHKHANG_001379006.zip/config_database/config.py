
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_FOLDER = BASE_DIR / "Access"
DB_PATH = BASE_DIR / "library_item.db"


API_KEY = "eba3c43588mshc4040259c4cd49dp1a0084jsn090f7e409b44"