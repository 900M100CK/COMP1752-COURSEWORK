from main_window import BaseWindow

if __name__ == '__main__':
    BaseWindow()
